# xali's Enchanted Books - Emissive Textures by GrandmaPork
 
